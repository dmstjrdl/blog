package hello.blog.user.enums;

public enum Role {
    USER, ADMIN
}
