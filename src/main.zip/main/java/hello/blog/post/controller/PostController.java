package hello.blog.post.controller;

import hello.blog.CustomUserDetails;
import hello.blog.post.domain.Post;
import hello.blog.post.service.PostService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class PostController {

    private final PostService postService;

    @GetMapping("/post/add")
    public String addPostForm() {
        return "postAddForm";
    }

    @PostMapping("/post/add")
    public String addPost(@ModelAttribute Post post, @AuthenticationPrincipal CustomUserDetails customUserDetails) {
        post.setUser(customUserDetails.getUser());
        postService.addPost(post);
        return "redirect:/";
    }

    @GetMapping("/post/{postId}")
    public String postView(@PathVariable Long postId, @AuthenticationPrincipal UserDetails userDetails, Model model) {
        Post post = postService.postById(postId);

        post.setViews(post.getViews() + 1);
        postService.updatePost(postId, post);

        model.addAttribute("post", post);
        model.addAttribute("user", userDetails);
        return "postView";
    }

    @GetMapping("/post/edit")
    public String postEditForm(@RequestParam("postId") Long postId, Model model) {
        Post post = postService.postById(postId);
        model.addAttribute("post", post);
        return "postEditForm";
    }

    @PostMapping("/post/edit")
    public String postEdit(@RequestParam Long postId, @ModelAttribute Post post) {
        postService.updatePost(postId, post);
        return "redirect:/post/" + postId;
    }

    @GetMapping("/post/delete/{postId}")
    public String postDeleteForm(@PathVariable Long postId) {
        postService.deletePost(postId);
        return "redirect:/";
    }

    @GetMapping("/post/search")
    public String postSearchForm(@RequestParam String title, Model model) {
        List<Post> posts = postService.postByTitle(title);
        model.addAttribute("keyword", title);
        model.addAttribute("posts", posts);
        return "postSearchView";
    }
}
