package hello.blog.post.service;

import hello.blog.post.repository.PostRepository;
import hello.blog.post.domain.Post;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PostServiceImpl implements PostService {

    private final PostRepository postRepository;

    @Override
    public void addPost(Post post) {
        postRepository.save(post);
    }

    @Override
    public Post postById(Long postId) {
        return postRepository.findById(postId).orElseThrow(() -> new NullPointerException("Not Found Post"));
    }

    @Override
    public List<Post> postByTitle(String title) {
        return postRepository.findByTitleContainingIgnoreCase(title);
    }

    @Override
    public List<Post> getPosts() {
        return postRepository.findTop6ByOrderByIdDesc();
    }

    @Override
    public List<Post> postByUserId(Long userId) {
        return postRepository.findByUserId(userId);
    }

    @Override
    public void updatePost(Long postId, Post post) {
        Post findPost = postRepository.findById(postId).orElseThrow(() -> new NullPointerException("Not Found Post"));
        findPost.setTitle(post.getTitle());
        findPost.setContent(post.getContent());

        postRepository.save(findPost);
    }

    @Override
    public void deletePost(Long postId) {
        postRepository.deleteById(postId);
    }
}
