package hello.blog.post.service;

import hello.blog.post.domain.Post;

import java.util.List;

public interface PostService {

    void addPost(Post post);

    Post postById(Long postId);
    List<Post> postByTitle(String title);
    List<Post> getPosts();
    List<Post> postByUserId(Long userId);

    void updatePost(Long postId, Post post);

    void deletePost(Long postId);
}
